package com.maytech.test.controller;

import com.maytech.test.entity.User;
import com.maytech.test.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.SecureRandom;


@Controller
@RequestMapping("/users/")
public class UserController {
    @Autowired
    private UserRepository userRepository;

    //new user form
    @GetMapping("showForm")
    public String showUserForm(User user){
        return "add-user";
    }

    //user list
    @GetMapping("list")
    public String Users(Model model){
        model.addAttribute("users",this.userRepository.findAll());
        return "index";
    }

    //add new user post method
    @PostMapping("add")
    public String addStudent(@Valid User user, BindingResult result, Model model){
        if (result.hasErrors()){
            return "add-user";
        }

        BCryptPasswordEncoder bCryptPasswordEncoder =
                new BCryptPasswordEncoder(10, new SecureRandom());
        String encryptedPassword= bCryptPasswordEncoder.encode(user.getPassword());
        user.setPassword(encryptedPassword);
        user.setStatus(true);
        this.userRepository.save(user);
        return "redirect:list";
    }

    //get edit form
    @GetMapping("edit/{id}")
    public String showUpdateForm(@PathVariable("id") long id,Model model){
        User user=this.userRepository.findById(id)
                .orElseThrow(()->new IllegalArgumentException("invalid user id :"+id));
        model.addAttribute("user",user);
        return "update-user";
    }

    //update user
    @PostMapping("update/{id}")
    public String updateUser(@PathVariable("id") long id,@Valid User user,BindingResult result,Model model){
        if (result.hasErrors()){
            user.setId(id);
            return "update-user";
        }
        userRepository.save(user);
        model.addAttribute("users",this.userRepository.findAll());
        return "index";
    }

    //delete user
    @GetMapping("delete/{id}")
    public String deleteUser(@PathVariable("id") long id,Model model){
        User user=this.userRepository.findById(id)
                .orElseThrow(()->new IllegalArgumentException("invalid user id :"+id));
        this.userRepository.delete(user);
        model.addAttribute("users",this.userRepository.findAll());
        return "index";
    }
}
